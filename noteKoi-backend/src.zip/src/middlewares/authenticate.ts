import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { env } from "../config/index.js";
import { ApiError } from "../types/index.js";
import { Role, VerificationStatus } from "@prisma/client";

export interface JwtPayload {
  sub: string; // userId
  role: Role;
  verificationStatus: VerificationStatus;
  collegeId: string;
  classroomUnitId: string | null;
  type: "access";
}

/**
 * Layer-2 of the 4-layer guard stack (ai-context.md §6).
 *
 * Verifies the Bearer access token and attaches the decoded payload to
 * `req.user`. Optionally enforces `verificationStatus === VERIFIED` for
 * endpoints that require it (INV-005).
 */
export function authenticate(opts: { requireVerified?: boolean } = {}) {
  return (req: Request, _res: Response, next: NextFunction) => {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith("Bearer ")) {
      return next(ApiError.unauthorized("Missing or malformed Authorization header"));
    }

    const token = authHeader.slice(7);

    let decoded: JwtPayload;
    try {
      decoded = jwt.verify(token, env.JWT_ACCESS_SECRET) as JwtPayload;
    } catch {
      return next(ApiError.unauthorized("Invalid or expired access token"));
    }

    if (decoded.type !== "access") {
      return next(ApiError.unauthorized("Token type mismatch"));
    }

    req.user = {
      ...decoded,
      id: decoded.sub,
    };

    // INV-005: private-resource endpoints must reject unverified users
    if (opts.requireVerified && decoded.verificationStatus !== VerificationStatus.VERIFIED) {
      return next(
        ApiError.forbidden(
          "Your account must be verified before accessing this resource",
        ),
      );
    }

    next();
  };
}
