import type { Metadata } from "next";
import "@/app/globals.css";
import { AppProviders } from "@/components/shared/app-providers";
import { AppShell } from "@/components/shared/app-shell";

export const metadata: Metadata = {
  title: "NoteKoi",
  description: "A collaborative resource sharing platform for students and teachers."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-950 text-slate-100">
        <AppProviders>
          <AppShell>{children}</AppShell>
        </AppProviders>
      </body>
    </html>
  );
}
